import { useState } from "react";
import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import REITList from "@/components/REITList";
import BuyModal from "@/components/BuyModal";
import DematAccount, { Holding } from "@/components/DematAccount";
import Footer from "@/components/Footer";
import { REIT } from "@/components/REITList";
import { useToast } from "@/hooks/use-toast";

const Index = () => {
  const [selectedReit, setSelectedReit] = useState<REIT | null>(null);
  const [isBuyModalOpen, setIsBuyModalOpen] = useState(false);
  
  const [holdings, setHoldings] = useState<Holding[]>([]);
  const { toast } = useToast();

  const handleBuyClick = (reit: REIT) => {
    setSelectedReit(reit);
    setIsBuyModalOpen(true);
  };

  const handleConfirmPurchase = (reit: REIT, amount: number, tokens: number) => {
    const newHolding: Holding = {
      reit,
      tokens,
      costBasis: amount,
      purchaseDate: new Date(),
    };

    setHoldings([...holdings, newHolding]);
    
    toast({
      title: "Purchase Successful!",
      description: `You've successfully purchased ${tokens} tokens of ${reit.name} for ₹${amount.toFixed(2)}`,
    });

    setIsBuyModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <Hero />
      <REITList onBuyClick={handleBuyClick} />
      <DematAccount holdings={holdings} />
      <Footer />
      
      <BuyModal
        isOpen={isBuyModalOpen}
        onClose={() => setIsBuyModalOpen(false)}
        reit={selectedReit}
        onConfirmPurchase={handleConfirmPurchase}
      />
    </div>
  );
};

export default Index;
