import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { User, Wallet, TrendingUp, TrendingDown, ToggleLeft, ToggleRight } from "lucide-react";
import { useState } from "react";
import { REIT } from "./REITList";

export interface Holding {
  reit: REIT;
  tokens: number;
  costBasis: number;
  purchaseDate: Date;
}

interface DematAccountProps {
  holdings: Holding[];
}

const DematAccount = ({ holdings }: DematAccountProps) => {
  const [showBlockchainView, setShowBlockchainView] = useState(false);

  const totalInvested = holdings.reduce((sum, h) => sum + h.costBasis, 0);
  const totalCurrentValue = holdings.reduce((sum, h) => sum + (h.reit.price * h.tokens / 100), 0);
  const totalPnL = totalCurrentValue - totalInvested;
  const totalPnLPercent = totalInvested > 0 ? (totalPnL / totalInvested) * 100 : 0;

  return (
    <section id="demat" className="py-12 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-bold text-foreground">My Demo Demat Account</h2>
          <Button
            variant="outline"
            onClick={() => setShowBlockchainView(!showBlockchainView)}
            className="flex items-center gap-2"
          >
            {showBlockchainView ? <ToggleRight className="w-5 h-5" /> : <ToggleLeft className="w-5 h-5" />}
            {showBlockchainView ? "Token View" : "Standard View"}
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6 bg-gradient-to-br from-card to-secondary/30">
            <div className="flex items-start justify-between mb-2">
              <User className="w-8 h-8 text-primary" />
            </div>
            <p className="text-sm text-muted-foreground mb-1">Account Holder</p>
            <p className="text-xl font-bold text-foreground">Demo Investor</p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-card to-secondary/30">
            <div className="flex items-start justify-between mb-2">
              <Wallet className="w-8 h-8 text-primary" />
            </div>
            <p className="text-sm text-muted-foreground mb-1">Total Invested</p>
            <p className="text-xl font-bold text-foreground">₹{totalInvested.toFixed(2)}</p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-card to-secondary/30">
            <div className="flex items-start justify-between mb-2">
              {totalPnL >= 0 ? (
                <TrendingUp className="w-8 h-8 text-green-600" />
              ) : (
                <TrendingDown className="w-8 h-8 text-red-600" />
              )}
            </div>
            <p className="text-sm text-muted-foreground mb-1">Current Value</p>
            <p className="text-xl font-bold text-foreground">₹{totalCurrentValue.toFixed(2)}</p>
            <p className={`text-sm ${totalPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {totalPnL >= 0 ? '+' : ''}{totalPnL.toFixed(2)} ({totalPnLPercent >= 0 ? '+' : ''}{totalPnLPercent.toFixed(2)}%)
            </p>
          </Card>
        </div>

        {holdings.length === 0 ? (
          <Card className="p-12 text-center">
            <div className="flex flex-col items-center gap-4">
              <Wallet className="w-16 h-16 text-muted-foreground" />
              <div>
                <h3 className="text-xl font-semibold text-foreground mb-2">No Holdings Yet</h3>
                <p className="text-muted-foreground">Start investing in REITs to see your portfolio here</p>
              </div>
            </div>
          </Card>
        ) : (
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              {!showBlockchainView ? (
                <table className="w-full">
                  <thead className="bg-secondary">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">REIT Name</th>
                      <th className="px-6 py-4 text-right text-sm font-semibold text-foreground">Tokens</th>
                      <th className="px-6 py-4 text-right text-sm font-semibold text-foreground">Cost Basis</th>
                      <th className="px-6 py-4 text-right text-sm font-semibold text-foreground">Current Value</th>
                      <th className="px-6 py-4 text-right text-sm font-semibold text-foreground">P&L</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {holdings.map((holding, index) => {
                      const currentValue = (holding.reit.price * holding.tokens) / 100;
                      const pnl = currentValue - holding.costBasis;
                      const pnlPercent = (pnl / holding.costBasis) * 100;

                      return (
                        <tr key={index} className="hover:bg-secondary/50 transition-colors">
                          <td className="px-6 py-4 text-sm text-foreground">{holding.reit.name}</td>
                          <td className="px-6 py-4 text-sm text-right text-foreground">{holding.tokens}</td>
                          <td className="px-6 py-4 text-sm text-right text-foreground">₹{holding.costBasis.toFixed(2)}</td>
                          <td className="px-6 py-4 text-sm text-right text-foreground">₹{currentValue.toFixed(2)}</td>
                          <td className={`px-6 py-4 text-sm text-right font-semibold ${pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {pnl >= 0 ? '+' : ''}₹{pnl.toFixed(2)} ({pnlPercent >= 0 ? '+' : ''}{pnlPercent.toFixed(2)}%)
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              ) : (
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-4 text-foreground">Blockchain Token Ledger</h3>
                  <div className="space-y-4">
                    {holdings.map((holding, index) => (
                      <Card key={index} className="p-4 bg-secondary/30 border-l-4 border-accent">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-xs text-muted-foreground">Token ID</p>
                            <p className="text-sm font-mono text-foreground">TRX-{holding.reit.id}-{index.toString().padStart(6, '0')}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Purchase Date</p>
                            <p className="text-sm text-foreground">{holding.purchaseDate.toLocaleDateString()}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">REIT Name</p>
                            <p className="text-sm text-foreground">{holding.reit.name}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Token Units</p>
                            <p className="text-sm font-semibold text-accent">{holding.tokens} tokens</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Amount (INR)</p>
                            <p className="text-sm text-foreground">₹{holding.costBasis.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Current Value</p>
                            <p className="text-sm text-foreground">₹{((holding.reit.price * holding.tokens) / 100).toFixed(2)}</p>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </Card>
        )}
      </div>
    </section>
  );
};

export default DematAccount;
