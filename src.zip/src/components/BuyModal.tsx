import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { REIT } from "./REITList";
import { Coins } from "lucide-react";

interface BuyModalProps {
  isOpen: boolean;
  onClose: () => void;
  reit: REIT | null;
  onConfirmPurchase: (reit: REIT, amount: number, tokens: number) => void;
}

const BuyModal = ({ isOpen, onClose, reit, onConfirmPurchase }: BuyModalProps) => {
  const [amount, setAmount] = useState("");
  const [purchaseType, setPurchaseType] = useState<"amount" | "tokens">("amount");

  if (!reit) return null;

  // Logic: 100 tokens = 1 REIT share at current share price
  // So 1 token = (reit.price / 100) INR
  const pricePerToken = reit.price / 100;
  
  const tokensFromAmount = Math.floor(Number(amount) / pricePerToken);
  const amountFromTokens = Number(amount) * pricePerToken;
  
  const calculatedTokens = purchaseType === "amount" ? tokensFromAmount : Number(amount);
  const calculatedAmount = purchaseType === "amount" ? Number(amount) : amountFromTokens;

  const handleConfirm = () => {
    if (calculatedAmount > 0 && calculatedTokens > 0) {
      onConfirmPurchase(reit, calculatedAmount, calculatedTokens);
      setAmount("");
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-accent" />
            Buy Fractional Share
          </DialogTitle>
          <DialogDescription>
            {reit.name} - ₹{reit.price} per share
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex gap-2 mb-4">
            <Button
              variant={purchaseType === "amount" ? "default" : "outline"}
              onClick={() => {
                setPurchaseType("amount");
                setAmount("");
              }}
              className={purchaseType === "amount" ? "bg-primary" : ""}
            >
              Enter Amount
            </Button>
            <Button
              variant={purchaseType === "tokens" ? "default" : "outline"}
              onClick={() => {
                setPurchaseType("tokens");
                setAmount("");
              }}
              className={purchaseType === "tokens" ? "bg-primary" : ""}
            >
              Enter Tokens
            </Button>
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">
              {purchaseType === "amount" ? "Amount (INR)" : "Number of Tokens"}
            </Label>
            <Input
              id="amount"
              type="number"
              placeholder={purchaseType === "amount" ? "Enter amount in ₹" : "Enter number of tokens"}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min="0"
            />
          </div>

          <div className="bg-secondary/50 p-4 rounded-lg space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Share Price:</span>
              <span className="font-semibold">₹{reit.price}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Price per Token:</span>
              <span className="font-semibold">₹{pricePerToken.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">You will receive:</span>
              <span className="font-semibold text-accent">{calculatedTokens || 0} tokens</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Total Cost:</span>
              <span className="font-bold text-lg">₹{(calculatedAmount || 0).toFixed(2)}</span>
            </div>
          </div>

          <div className="text-xs text-muted-foreground bg-muted/50 p-3 rounded">
            <p>Note: 100 tokens = 1 share of {reit.name}. 
            Current share price: ₹{reit.price}, so 1 token = ₹{pricePerToken.toFixed(2)}</p>
          </div>
        </div>

        <DialogFooter className="flex gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleConfirm}
            disabled={!amount || Number(amount) <= 0}
            className="bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            Confirm Purchase
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default BuyModal;
