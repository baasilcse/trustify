import { Shield, Mail, FileText, Lock } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
                <span className="text-accent-foreground font-bold text-xl">T</span>
              </div>
              <span className="font-bold text-xl">TrustifyX</span>
            </div>
            <p className="text-primary-foreground/80 text-sm">
              Democratizing commercial real estate investment through blockchain tokenization.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Important Links
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#terms" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  Terms & Conditions
                </a>
              </li>
              <li>
                <a href="#privacy" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#contact" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors flex items-center gap-2">
                  <Mail className="w-3 h-3" />
                  Contact Us
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Security & Compliance
            </h3>
            <div className="flex flex-wrap gap-2">
              <span className="text-xs bg-accent/20 px-3 py-1 rounded-full">SEBI Compliant</span>
              <span className="text-xs bg-accent/20 px-3 py-1 rounded-full">Blockchain Secured</span>
              <span className="text-xs bg-accent/20 px-3 py-1 rounded-full flex items-center gap-1">
                <Lock className="w-3 h-3" />
                SSL Encrypted
              </span>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8">
          <div className="bg-accent/10 p-4 rounded-lg mb-6">
            <p className="text-sm text-primary-foreground/90 mb-2">
              <strong>DISCLAIMER:</strong> This is a demo platform for educational purposes only.
            </p>
            <p className="text-xs text-primary-foreground/70">
              TrustifyX is a proof-of-concept showcasing fractional real estate investment through blockchain tokenization. 
              All transactions, prices, and portfolio data displayed are simulated. Actual investing in REITs and securities 
              involves market risks, including possible loss of principal. Past performance is not indicative of future results. 
              Please consult with a qualified financial advisor before making any investment decisions. SEBI registration and 
              regulatory compliance are required for real-world operations.
            </p>
          </div>

          <div className="text-center text-sm text-primary-foreground/70">
            <p>© 2025 TrustifyX. All rights reserved. | Powered by blockchain technology</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
