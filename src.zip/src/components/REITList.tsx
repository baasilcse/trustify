import { Building2, ShoppingBag, TrendingUp, ArrowUpDown } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { useState } from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./ui/tooltip";

export interface REIT {
  id: string;
  name: string;
  price: number;
  description: string;
  assetType: "Office" | "Retail" | "Mixed";
  portfolio: string;
  aum: string;
  yield: string;
}

const reits: REIT[] = [
  {
    id: "1",
    name: "Brookfield India Real Estate Trust",
    price: 343,
    description: "Premium office spaces across major Indian metros",
    assetType: "Office",
    portfolio: "15+ Grade A office properties in Mumbai, Gurugram, Noida, Kolkata",
    aum: "₹18,500 Cr",
    yield: "7.2% p.a."
  },
  {
    id: "2",
    name: "Embassy Office Parks REIT",
    price: 421,
    description: "India's first listed REIT with Grade A office parks",
    assetType: "Office",
    portfolio: "33 million sq ft across Bengaluru, Mumbai, Pune, NCR",
    aum: "₹32,000 Cr",
    yield: "6.8% p.a."
  },
  {
    id: "3",
    name: "Mindspace Business Parks REIT",
    price: 458,
    description: "Quality office portfolios in key business districts",
    assetType: "Office",
    portfolio: "29.5 million sq ft in Mumbai, Pune, Hyderabad, Chennai",
    aum: "₹21,500 Cr",
    yield: "7.5% p.a."
  },
  {
    id: "4",
    name: "Nexus Select Trust",
    price: 160,
    description: "Retail and shopping mall focused REIT",
    assetType: "Retail",
    portfolio: "17 retail properties across 14 cities",
    aum: "₹8,200 Cr",
    yield: "8.1% p.a."
  },
  {
    id: "5",
    name: "Knowledge Realty Trust",
    price: 250,
    description: "Upcoming listing - IT parks and commercial spaces",
    assetType: "Mixed",
    portfolio: "Pipeline - IT parks in Tier 1 & 2 cities",
    aum: "₹5,000 Cr (Est.)",
    yield: "7.0% p.a. (Est.)"
  }
];

interface REITListProps {
  onBuyClick: (reit: REIT) => void;
}

const REITList = ({ onBuyClick }: REITListProps) => {
  const [sortBy, setSortBy] = useState<"price" | "name">("price");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");

  const sortedReits = [...reits].sort((a, b) => {
    const multiplier = sortOrder === "asc" ? 1 : -1;
    if (sortBy === "price") {
      return (a.price - b.price) * multiplier;
    }
    return a.name.localeCompare(b.name) * multiplier;
  });

  const toggleSort = () => {
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };

  const AssetIcon = ({ type }: { type: REIT["assetType"] }) => {
    if (type === "Office") return <Building2 className="w-5 h-5 text-primary" />;
    if (type === "Retail") return <ShoppingBag className="w-5 h-5 text-primary" />;
    return <TrendingUp className="w-5 h-5 text-primary" />;
  };

  return (
    <section id="invest" className="py-12 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-foreground">Available REITs</h2>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSortBy("price")}
              className={sortBy === "price" ? "bg-primary text-primary-foreground" : ""}
            >
              Sort by Price
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSortBy("name")}
              className={sortBy === "name" ? "bg-primary text-primary-foreground" : ""}
            >
              Sort by Name
            </Button>
            <Button variant="outline" size="sm" onClick={toggleSort}>
              <ArrowUpDown className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedReits.map((reit) => (
            <TooltipProvider key={reit.id}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Card className="p-6 hover:shadow-lg transition-all duration-300 cursor-pointer border-border bg-card">
                    <div className="flex items-start justify-between mb-4">
                      <AssetIcon type={reit.assetType} />
                      <span className="text-xs bg-secondary px-2 py-1 rounded-full text-secondary-foreground">
                        {reit.assetType}
                      </span>
                    </div>
                    
                    <h3 className="font-semibold text-lg mb-2 text-card-foreground line-clamp-2">
                      {reit.name}
                    </h3>
                    
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {reit.description}
                    </p>
                    
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <p className="text-xs text-muted-foreground">Current Price</p>
                        <p className="text-2xl font-bold text-foreground">₹{reit.price}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">Yield</p>
                        <p className="text-sm font-semibold text-green-600">{reit.yield}</p>
                      </div>
                    </div>
                    
                    <Button
                      onClick={() => onBuyClick(reit)}
                      className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                    >
                      Buy Fractional Share
                    </Button>
                  </Card>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <div className="space-y-2">
                    <p className="font-semibold">Portfolio Details:</p>
                    <p className="text-sm">{reit.portfolio}</p>
                    <p className="text-sm"><strong>AUM:</strong> {reit.aum}</p>
                    <p className="text-sm"><strong>Yield:</strong> {reit.yield}</p>
                  </div>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>
      </div>
    </section>
  );
};

export default REITList;
