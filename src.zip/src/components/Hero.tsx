import { Coins, TrendingUp, Shield } from "lucide-react";

const Hero = () => {
  return (
    <section id="home" className="bg-gradient-to-r from-primary to-primary/90 py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-3xl md:text-5xl font-bold text-primary-foreground mb-4 leading-tight">
              Own a slice of India's premium commercial real estate
            </h1>
            <p className="text-xl text-primary-foreground/90 mb-6">
              – powered by tokens
            </p>
            <div className="flex flex-wrap gap-6 justify-center md:justify-start">
              <div className="flex items-center gap-2 text-primary-foreground">
                <Shield className="w-5 h-5" />
                <span className="text-sm">Secure & Transparent</span>
              </div>
              <div className="flex items-center gap-2 text-primary-foreground">
                <Coins className="w-5 h-5" />
                <span className="text-sm">Fractional Ownership</span>
              </div>
              <div className="flex items-center gap-2 text-primary-foreground">
                <TrendingUp className="w-5 h-5" />
                <span className="text-sm">Real-time Trading</span>
              </div>
            </div>
          </div>
          
          <div className="flex-1 flex justify-center">
            <div className="relative">
              <div className="w-64 h-64 bg-primary-foreground/10 rounded-full flex items-center justify-center backdrop-blur-sm">
                <Coins className="w-32 h-32 text-accent animate-pulse" />
              </div>
              <div className="absolute top-0 right-0 w-16 h-16 bg-accent rounded-full flex items-center justify-center animate-bounce">
                <Shield className="w-8 h-8 text-accent-foreground" />
              </div>
              <div className="absolute bottom-0 left-0 w-16 h-16 bg-accent rounded-full flex items-center justify-center animate-bounce" style={{ animationDelay: "0.2s" }}>
                <TrendingUp className="w-8 h-8 text-accent-foreground" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
